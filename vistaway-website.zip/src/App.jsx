import React from "react";
import "./App.css";

export default function VistaWayHome() {
  return (
    <div className="min-h-screen bg-[#F5F5F0] text-[#1F2F6F] font-sans">
      <header className="text-center py-10">
        <h1 className="text-4xl font-bold">VistaWay</h1>
        <p className="text-lg mt-2 text-[#3ACFC4]">Travel with Vision</p>
      </header>

      <section className="px-6 md:px-20 py-10">
        <h2 className="text-2xl font-semibold mb-4">What is VistaWay?</h2>
        <p className="text-base text-gray-700">
          VistaWay creates meaningful, small-group travel experiences for young explorers who crave culture, connection, and personal growth. Our journeys go beyond sightseeing – they’re designed to inspire and transform.
        </p>
      </section>

      <section className="bg-white px-6 md:px-20 py-10">
        <h2 className="text-2xl font-semibold mb-4 text-[#FF6B6B]">Next Trip: Italy with Feeling</h2>
        <ul className="list-disc list-inside text-gray-800 mb-4">
          <li>5 days / 4 nights: Rome + Tuscany</li>
          <li>Workshops: Pasta making, local culture & language</li>
          <li>Small group (max 12 people)</li>
          <li>Personal travel journal + certification</li>
        </ul>
        <button className="bg-[#3ACFC4] text-white px-6 py-2 rounded-xl shadow-md hover:bg-[#2db6a9] transition">Apply Now</button>
      </section>

      <section className="px-6 md:px-20 py-10">
        <h2 className="text-2xl font-semibold mb-4">What Our Travelers Say</h2>
        <blockquote className="italic text-gray-600">“VistaWay was more than a trip – it was a reset for my mindset. I met amazing people and felt deeply connected to every place we visited.”</blockquote>
        <p className="mt-2 text-right text-sm">– Emma, 26</p>
      </section>

      <section className="bg-white px-6 md:px-20 py-10 text-center">
        <h2 className="text-2xl font-semibold mb-4">Join Our Journey</h2>
        <p className="text-gray-700 mb-4">Subscribe to get updates on upcoming trips, stories and early access.</p>
        <input type="email" placeholder="Your email" className="px-4 py-2 rounded-md border border-gray-300 mr-2" />
        <button className="bg-[#FF6B6B] text-white px-4 py-2 rounded-md hover:bg-[#e35a5a] transition">Subscribe</button>
      </section>

      <footer className="text-center text-sm text-gray-500 py-6">
        &copy; 2025 VistaWay. All rights reserved.
      </footer>
    </div>
  );
}